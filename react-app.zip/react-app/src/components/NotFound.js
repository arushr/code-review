import React from "react";

const NotFound = () => (
  <div>
    <h2 align="center">Page Not Found</h2>
  </div>
);

export default NotFound;
