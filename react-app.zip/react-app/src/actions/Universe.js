import * as UniverseActionTypes from "../actiontypes/Universe";

export const collapseA = () => {
  return { type: UniverseActionTypes.COLLAPSE_UNIVERSE_A };
};
export const collapseB = () => {
  return { type: UniverseActionTypes.COLLAPSE_UNIVERSE_B };
};
