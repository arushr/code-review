export const COLLAPSE_UNIVERSE_A = "character/COLLAPSE_UNIVERSE_A";
export const COLLAPSE_UNIVERSE_B = "character/COLLAPSE_UNIVERSE_B";
